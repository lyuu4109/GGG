import React from 'react'

export default function Feedback() {
  return (
    <div>
      <h1 style={{textAlign:"center"}}>no feedback</h1>
    </div>
  )
}
