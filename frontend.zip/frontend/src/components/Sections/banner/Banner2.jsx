import React from "react";
import styles from "./Banner.module.css";
import Link from "next/link";
export default function Banner2() {
  return (
    <div>
      <div
        className={styles.bannerCOl}
        style={{
          backgroundImage:
            "url('https://images.ctfassets.net/bdvz0u6oqffk/6Nt6EReVvGm6QkCuGyqkK/68ea21684b8178c18ffc60d66e26d032/about-hero.jpg')",
        }}
      >
        <h1>
          The one-stop destination for buying,<br />
          selling and exploring fashion.
        </h1>
        <button
          style={{
            padding: "15px 20px ",
            background: "blue",
            color: "white",
            width: "200px",
            fontSize: "20px",
            margin: "20px",
          }}
        >
          <Link className={styles.bottomBannerButton} href={`/products`}>SHOP ALL</Link>
        </button>
      </div>
    </div>
  );
}
