const data = [
{
    img:"https://images.ctfassets.net/bdvz0u6oqffk/7B3l272lM7gre9Xlameswk/2f723c0dd0dfe84d84dd7a3eee26643f/Avant-Garde.jpg?fm=webp&h=245&w=390",
    title:" Avant-Garde",
    path:""

},
{
    img:"https://images.ctfassets.net/bdvz0u6oqffk/5f0B7h5OaBWCydaesCaLmD/4001833a12218e8b09603e33c1e087a7/Gorpcore.jpg?fm=webp&h=245&w=390",
    title:"  Gorpcore",
    path:""

},
{
    img:"https://images.ctfassets.net/bdvz0u6oqffk/6GhvB56cQL3WD2F8iaGSIT/dd711e8c991cc094cc3e35e77ad5dbe5/Luxury.jpg?fm=webp&h=245&w=390",
    title:" Luxury",
    path:""

},
{
    img:"https://images.ctfassets.net/bdvz0u6oqffk/2zQdoANVf1HNj8pWSUQeYZ/fec7620e9dd8e0079122e46b51818930/Streetwear.jpg?fm=webp&h=245&w=390",
    title:"Streetwear",
    path:""

},
{
    img:"https://images.ctfassets.net/bdvz0u6oqffk/38J3a8TwH6JDzB5SAkLkMG/1f6bb214f0ea72bc43c477e04d23aecf/Vintage.jpg?fm=webp&h=245&w=390",
    title:" Vintage",
    path:""

},
{
    img:"https://images.ctfassets.net/bdvz0u6oqffk/4weM83NSsbts6EYymZW0fU/2bc64d36456cff1cdd390257a0ef8246/Y2K.jpg?fm=webp&h=245&w=390",
    title:" Y2K",
    path:""
    
}
]


export default data