"use client";
import { useState } from "react";
import style from "./style.module.css";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
// import required modules
import { FreeMode, Thumbs } from "swiper/modules";
// import required modules
import { Navigation } from "swiper/modules";
export default function ProductSlider({ productImages }) {
  const [thumbsSwiper, setThumbsSwiper] = useState(null);
  return (
    <div className={style.div}>
      <Swiper
        style={{
          "--swiper-navigation-color": "#080707",
          "--swiper-pagination-color": "#000000",
        }}
        spaceBetween={10}
        navigation={true}
        thumbs={{ swiper: thumbsSwiper }}
        modules={[FreeMode, Navigation, Thumbs]}
      >
        {productImages?.map((item) => (
          <SwiperSlide>
            <img
              src={process.env.NEXT_PUBLIC_SERVER_API + "uploads/" + item}
              alt={"Product Slider Image"}
              height={"500px"}
              width={"100%"}
              style={{ objectFit: "cover" }}
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}
