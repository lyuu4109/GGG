import React, {useEffect, useState} from "react";
import styled from "styled-components";
import axios from "axios";
import {ToastContainer, toast} from "react-toastify";
import style from './style.module.css'


const Tab = styled.button`
    padding: 20px;
    cursor: pointer;
    text-transform: uppercase;
    font-size: 12pt;
    width: 100%;
    font-weight: bold;
    opacity: 0.6;
    background: whitesmoke;
    outline: 0;
    border: 1px solid lightgray;
    transition: ease border-bottom 250ms, ease background 250ms;
    ${({ active }) =>
            active &&
            `
    border-bottom: 3px solid black;
    background: white;
    opacity: 1;
  `}
`;


export default function MessagesSection() {
    // const { user } = UseAuth();
    const [user, setUser] = useState(null);
    const types = ["Buy", "Sell"];
    const [selectedType, setSelectedType] = useState(types[0]);
    const [buyMessages, setBuyMessages] = useState([]);


    const fetchBuyMessages = () => {
        // Perform your API call using Axios here to fetch buy messages
        // For example:
        axios.get("https://adminpanellive.vercel.app/api/contact")
            .then(response => setBuyMessages(filterBuyMessages(response.data)))
            .catch(error => console.error("Error fetching buy messages:", error));
    };

    useEffect(() => {
        fetchBuyMessages();
    }, []); // Empty dependency array ensures this effect runs only once, on mount

    // useEffect hook to fetch buy messages whenever selectedType changes to "Buy"
    useEffect(() => {
        if (selectedType === "Buy") {
            fetchBuyMessages();
        }
    }, [selectedType, user]); // Runs whenever selectedType changes


    const filterBuyMessages = (messages) => {
        try {
            console.log(messages)
            const messagesToShow = messages.Contacts.filter((message) => message.email === user?.email)
                .map((message) => {return {msg: message.description, link: message.listingUrl}});
            console.log(messagesToShow)
            return messagesToShow
        } catch (e) {
            toast.error("Error filtering buy messages");
            console.error(e.message,e);
            return []
        }
    }

    const handleItemClick = (url) => {
        window.open(url, '_blank'); // Open the URL in a new tab
    };


    return (
    <div className={style.container} >
        <div className={style.tabs} >
            { types.map((type) => (
                <Tab active={selectedType === type} onClick={() => setSelectedType(type)}>
                    {type} Messages
                </Tab>
            ))}
        </div>
            {selectedType === "Buy" && (
                <div className={style.messageArea}>
                    {(!(buyMessages.length === 0)) ? (
                    <ul className={style.message}>
                        {buyMessages.map((message, index) => (
                            <li key={index}>
                                <p>
                                    {message.msg}
                                </p>
                                <div className={style.btnArea}>
                                    <button onClick={()=> handleItemClick(message.link)} className={style.btnBuy}>BUY NOW</button>
                                    <button onClick={()=> handleItemClick(message.link)} className={style.btnOffer}>OFFER</button>
                                </div>
                            </li>
                        ))}
                    </ul>
                    ) : (
                    <p>
                        Your conversations will appear here when you make an offer, ask a question, or purchase an item.
                    </p>
                    )}
                </div>
            )}
            {selectedType === "Sell" && (
                <div className={style.messageArea}>
                    <p>
                        Your conversations around items you are selling will appear here.
                    </p>
                </div>
            )}
    </div>
  );
}