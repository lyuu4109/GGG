"use client";
import Link from "next/link";
import style from "./Style.module.css";
export default function NestedMenu() {
  return (
    <ul className={style.nestedmenu}>
      <li>
        <Link href="/products/designer"> DESIGNERS</Link>
      </li>
      <li className={style.sub1}>
        <Link href="/"> MENSWEAR</Link>
        <svg
          className="-toggle ToggleCaret-module__down___LufHC"
          height="4px"
          width="7px"
          aria-hidden="true"
          style={{ marginLeft: "3px", alignSelf: "center" }}
          viewBox="0 0 7 4"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M0 0L3.49216 3.49095L7 0H0Z"
            fill="black"
          ></path>
        </svg>
        <ul className={style.submenu1}>
          <li>
            <Link href="/products"> ALL CATEGORIES</Link>
          </li>
          <li className={style.submenu1Sub}>
            <Link href="/products/cetagory/menswear/tops">TOPS</Link>

            <ul className={style.subMenu1subMenu}>
              <li>
                <Link href="/products/cetagory/menswear/tops">
                  {" "}
                  LONG SLEEVE T-SHIRTS
                </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/tops">POLOS </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/tops">
                  SHIRTS (BUTTON UPS){" "}
                </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/tops">
                  SHORT SLEEVE T-SHIRTS{" "}
                </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/top">
                  SHORT SLEEVE T-SHIRTS{" "}
                </Link>
              </li>
            </ul>
          </li>
          <li className={style.submenu2Sub}>
            <Link href="/products/cetagory/menswear/bottoms">BOTTOMS</Link>
            <ul className={style.subMenu2subMenu}>
              <li>
                <Link href="/products/cetagory/menswear/bottoms"> Pant</Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/bottoms">DENIMS </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/bottoms">Casual</Link>
              </li>
            </ul>
          </li>
          <li>
            <Link href="/products">OUTERWEAR</Link>
          </li>
          <li>
            <Link href="/products/cetagory/menswear/footwear">FOOTWEAR</Link>
          </li>
          <li>
            <Link href="/products">TAILORING</Link>
          </li>
          <li>
            <Link href="/products/cetagory/menswear/accessories">
              ACCESSORIES
            </Link>
          </li>
        </ul>
      </li>
      <li className={style.sub2}>
        <Link href="/products/cetagory/womenswear/tops"> WOMENSWEAR</Link>
        <svg
          className="-toggle ToggleCaret-module__down___LufHC"
          height="4px"
          width="7px"
          aria-hidden="true"
          style={{ marginLeft: "3px", alignSelf: "center" }}
          viewBox="0 0 7 4"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M0 0L3.49216 3.49095L7 0H0Z"
            fill="black"
          ></path>
        </svg>
        <ul className={style.submenu2}>
          <li>
            <Link href="/products"> ALL CATEGORIES</Link>
          </li>
          <li className={style.submenu3Sub}>
            <Link href="/products/cetagory/womenswear/tops">TOPS</Link>

            <ul className={style.subMenu3subMenu}>
              <li>
                <Link href="/products/cetagory/menswear/tops">
                  {" "}
                  LONG SLEEVE T-SHIRTS
                </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/tops">POLOS </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/tops">
                  SHIRTS (BUTTON UPS){" "}
                </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/tops">
                  SHORT SLEEVE T-SHIRTS{" "}
                </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/top">
                  SHORT SLEEVE T-SHIRTS{" "}
                </Link>
              </li>
            </ul>
          </li>
          <li className={style.submenu4Sub}>
            <Link href="/products/cetagory/menswear/bottoms">BOTTOMS</Link>
            <ul className={style.subMenu4subMenu}>
              <li>
                <Link href="/products/cetagory/menswear/bottoms"> Pant</Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/bottoms">DENIMS </Link>
              </li>
              <li>
                <Link href="/products/cetagory/menswear/bottoms">Casual</Link>
              </li>
            </ul>
          </li>
          <li>
            <Link href="/products">OUTERWEAR</Link>
          </li>
          <li>
            <Link href="/products/cetagory/menswear/footwear">FOOTWEAR</Link>
          </li>
          <li>
            <Link href="/products">TAILORING</Link>
          </li>
          <li>
            <Link href="/products/cetagory/menswear/accessories">
              ACCESSORIES
            </Link>
          </li>
        </ul>
      </li>
      <li>
        <Link href="/products/cetagory/menswear/footwear"> SNEAKERS</Link>
      </li>
      <li>
        <Link href="/products/staf/"> STAFF PICKS</Link>
      </li>
      <li>
        <Link href="/products"> COLLECTIONS</Link>
      </li>
    </ul>
  );
}
