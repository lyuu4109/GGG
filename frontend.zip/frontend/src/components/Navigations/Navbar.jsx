"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Modals from "../authModal/Modals";
import Sidebar from "./Sidebar";
import style from "./Style.module.css";
import isUserLoggedIn from "@/lib/checkAuth";
// @refresh reset

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [modelType, setModelType] = useState("login");
  const handleOpen = (type) => {
    setModelType(type);
    setOpen(true);
  };
  const handleClose = () => setOpen(false);
  const [user, setUser] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    async function loginCheck() {
      if (!token) {
        setUser(false);
      } else {
        try {
          const user = await isUserLoggedIn(token);
          setUser(user.user);
        } catch (error) {
          console.error("Error checking user login status:", error);
          setUser(false);
        }
      }
      setLoading(false);
    }
    loginCheck();
  }, []);

  const handelLogout = async () => {
    try {
      setUser(false);
      localStorage.removeItem("authToken");
      router.push("/");
    } catch (err) {
      console.log(err);
    }
  };

  const handleSearch = async () => {
    router.push(`/products?search=${searchQuery}`);
  };

  return (
    <>
      <nav className={`${style.header}`}>
        <div className={style.logoCol}>
          <Link href={"/"}>
            <video
              className={style.logo}
              poster="https://assets.grailed.com/logo.jpg"
              width={120}
              autoPlay
              loop
              playsInline
              muted
              preload="none"
            >
              <source
                src="https://assets.grailed.com/logo.webm"
                type="video/webm"
              />
              <source
                src="https://assets.grailed.com/logo.mp4"
                type="video/mp4"
              />
            </video>
          </Link>
          <div className={style.inputcol}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 19 19"
              width={20}
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M12.6762 14.1493C11.3618 15.1535 9.71933 15.75 7.9375 15.75C3.62278 15.75 0.125 12.2522 0.125 7.9375C0.125 3.62278 3.62278 0.125 7.9375 0.125C12.2522 0.125 15.75 3.62278 15.75 7.9375C15.75 9.71928 15.1535 11.3617 14.1494 12.6761L18.57 17.0967L17.0968 18.5699L12.6762 14.1493ZM13.6667 7.9375C13.6667 11.1016 11.1016 13.6667 7.9375 13.6667C4.77337 13.6667 2.20833 11.1016 2.20833 7.9375C2.20833 4.77337 4.77337 2.20833 7.9375 2.20833C11.1016 2.20833 13.6667 4.77337 13.6667 7.9375Z"
                fill="black"
              ></path>
            </svg>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search"
              className={style.input}
            />
            <button onClick={handleSearch} className={style.btn3}>
              SEARCH
            </button>
          </div>
        </div>
        <ul className={style.links}>
          {loading ? null : !user ? (
            <li>
              <Link
                onClick={() => {
                  handleOpen("accountCreate");
                }}
                className={style.sell}
                href=""
              >
                SELL
              </Link>
            </li>
          ) : (
            <li>
              <Link className={style.sell} href={`/sell/${user._id}`}>
                SELL
              </Link>
            </li>
          )}

          <li>
            <Link href="/products"> SHOP</Link>
          </li>
          <li>
            <Link href="/reads">READ</Link>
          </li>
          {loading ? null : !user ? (
            ""
          ) : (
            <li>
              <Link href="/favorites">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 26 23"
                  stroke="currentColor"
                  width={20}
                >
                  <path
                    d="M23.8941 12.6944L14 22.5886H12L2.10585 12.6944C-0.701951 9.8866 -0.701951 5.33367 2.10585 2.52587C4.91366 -0.281938 9.46658 -0.281938 12.2744 2.52587L13 3.25148L13.7256 2.52587C16.5334 -0.281938 21.0863 -0.281938 23.8941 2.52587C26.702 5.33367 26.702 9.8866 23.8941 12.6944Z"
                    fill="black"
                  ></path>
                </svg>
              </Link>
            </li>
          )}
          {loading ? null : !user ? (
            <>
              <li>
                <Link href="">
                  <button
                    onClick={() => {
                      handleOpen("login");
                    }}
                    className={style.btn1}
                  >
                    LOGIN
                  </button>
                </Link>
              </li>
              <li>
                <Link href="">
                  <button
                    onClick={() => {
                      handleOpen("accountCreate");
                    }}
                    className={style.btn2}
                  >
                    SIGN UP
                  </button>
                </Link>
              </li>
            </>
          ) : (
            <li className={style.profileCon}>
              {" "}
              <Link href="/profile">
                <div className={style.userColwrapper}>
                  <Link href={`/profile/${user._id}`}>
                    <img
                      src={user.profile ? process.env.NEXT_PUBLIC_SERVER_API + "uploads/" + user.profile : "https://cdn-icons-png.flaticon.com/512/149/149071.png"}
                      className={style.profile}
                      alt=""
                    />
                  </Link>
                </div>
              </Link>
              <div className={style.prfilDropdown}>
                <Link
                  className={style.prfilDropdown_username}
                  href={`/profile/${user._id}`}
                >
                  {" "}
                  {!user.displayName
                    ? user.email.slice(0, 3)
                    : user.displayName}{" "}
                </Link>
                <Link href={"/messages"}>MESSAGES</Link>
                <Link href={"/favorites/"}>FAVORITES</Link>
                <Link href={"/messages"}>PURCHASES</Link>
                <Link href={`/sell/${user._id}`}>SELL</Link>
                <Link href={`/sell/${user._id}`}>FOR SALE</Link>
                <Link href={`/sell/${user._id}`}>SOLD</Link>
                <Link href={`/profile/${user._id}`}>MY ACCOUNT</Link>
                <Link onClick={handelLogout} href="">
                  SIGN OUT
                </Link>
              </div>
            </li>
          )}
        </ul>
        <ul className={style.mobileMenus}>
          {!user ? (
            <li
              onClick={() => {
                handleOpen("accountCreate");
              }}
            >
              Sign Up
            </li>
          ) : (
            <li>
              <Link href="/favorites">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  width={30}
                >
                  <path d="m11.645 20.91-.007-.003-.022-.012a15.247 15.247 0 0 1-.383-.218 25.18 25.18 0 0 1-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0 1 12 5.052 5.5 5.5 0 0 1 16.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 0 1-4.244 3.17 15.247 15.247 0 0 1-.383.219l-.022.012-.007.004-.003.001a.752.752 0 0 1-.704 0l-.003-.001Z" />
                </svg>
              </Link>
            </li>
          )}

          <li>
            <button className={style.bars} onClick={toggleSidebar}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth="1.5"
                stroke="currentColor"
                width={30}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
                />
              </svg>
            </button>
          </li>
        </ul>
      </nav>
      <Modals
        handleOpen={handleOpen}
        open={open}
        handleClose={handleClose}
        setOpen={setOpen}
        type={modelType}
        setUser={setUser}
      />
      <Sidebar toggleSidebar={toggleSidebar} isOpen={sidebarOpen} />
    </>
  );
}
