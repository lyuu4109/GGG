import React from "react";
import style from "./Loading.module.css";
import { Puff } from "react-loader-spinner";
export default function Loading({ text = "Loading.." }) {
  return (
    <div className={style.loading}>
      <Puff
        visible={true}
        height="80"
        width="80"
        color="#000"
        ariaLabel="puff-loading"
        wrapperStyle={{}}
        wrapperClass=""
      />
      <p>{text}</p>
    </div>
  );
}
