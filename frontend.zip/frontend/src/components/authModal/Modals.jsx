"use client";
import { useEffect, useState } from "react";
import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Login from "./Login";
import CreateAccount from "./CreateAccount";

const modalStyles = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  height: "80%",
  bgcolor: "background.paper",
  border: "1px solid #000",
  boxShadow: 24,
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  gap: "1rem",
  borderRadius: "5px",
  overflow: "auto",
  width: "60%", // Default width for tablets
  height: "fit-content",
  "@media (min-width: 1024px)": {
    // Computer width
    width: "35%",
  },

  "@media (max-width: 767px)": {
    // Mobile width
    width: "85%",
  },
};

export default function Modals({ open, handleClose, setOpen, type, setUser}) {

  const [activeTab, setActiveTab] = useState("login");

  useEffect(() => {
    // Update activeTab when type prop changes
    setActiveTab(type);
  }, [type]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={modalStyles}>
        {activeTab === "accountCreate" && (
          <CreateAccount tabChange={handleTabChange} />
        )}
        {activeTab === "login" && <Login tabChange={handleTabChange} setOpen={setOpen} setUser={setUser}/>}
      </Box>
    </Modal>
  );
}
