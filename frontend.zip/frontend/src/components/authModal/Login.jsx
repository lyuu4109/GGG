"use client";
import React, { useState } from "react";
import {
  CssBaseline,
  Typography,
  Grid,
  FormControlLabel,
  Checkbox,
  Button,
} from "@mui/material";
import Link from "next/link";
import { createTheme } from "@mui/material/styles";
import { styled } from "@mui/system"; // Import styled from @mui/system
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const theme = createTheme({
  palette: {
    primary: {
      main: "#000", // Black color for primary
    },
    secondary: {
      main: "#000", // Black color for secondary
    },
    error: {
      main: "#f44336", // Red color for error
    },
    background: {
      default: "#fff", // White color for background
    },
  },
});

// Define styles using the styled function
const StyledPaper = styled("div")({
  margin: theme.spacing(8, 4),
  marginTop: theme.spacing(8),
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
});

const StyledForm = styled("form")({
  width: "100%", // Fix IE 11 issue.
  marginTop: theme.spacing(3),
});

const StyledTextField = styled("input")({
  border: "2px solid #000",
  borderRadius: "4px",
  padding: "10px",
  width: "100%",
  boxSizing: "border-box",
  marginTop: theme.spacing(1),
});

const StyledSubmitButton = styled(Button)({
  margin: theme.spacing(3, 0, 2),
  backgroundColor: "#000", // Black color for background
  "&:hover": {
    backgroundColor: "#000", // Black color for background on hover
  },
  "&:focus": {
    backgroundColor: "#000", // Black color for background on focus
  },
  "&:active": {
    backgroundColor: "#000", // Black color for background on active
  },
});

export default function Login({ setOpen, tabChange, setUser }) {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post(
        process.env.NEXT_PUBLIC_SERVER_API + "api/user/login",
        formData
      );
      const authToken = response.data.token; // Assuming your server sends back the authentication token
      setUser(response.data.user);
      localStorage.setItem("authToken", authToken); // Store the token in local storage
      setLoading(false);
      setOpen(false);
      toast.success("Login successful!");
    } catch (error) {
      console.error("Error logging in:", error);
      setLoading(false);
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        toast.error(error.response.data.message);
      } else if (
        error.response &&
        error.response.data &&
        error.response.data.errors
      ) {
        toast.error(error.response.data.errors[0].msg);
      } else {
        toast.error("An error occurred. Please try again later.");
      }
    }
  };

  return (
    <>
      <CssBaseline />
      <ToastContainer />
      <StyledPaper>
        <Typography component="h1" variant="h4">
          Sign in
        </Typography>
        <Typography component="p" variant="body1">
          Login using your email and password!
        </Typography>
        <StyledForm onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <StyledTextField
                type="email"
                autoComplete="email"
                name="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <StyledTextField
                type="password"
                autoComplete="current-password"
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
          <StyledSubmitButton
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            disabled={loading}
          >
            {loading ? "Signing in..." : "Sign In"}
          </StyledSubmitButton>

          <Grid container justify="center" style={{ justifyContent: "center" }}>
            <Grid item>
              <Link href="#" variant="body2">
                Don't have an account?{" "}
                <span onClick={() => tabChange("accountCreate")}> Sign up</span>
              </Link>
            </Grid>
          </Grid>
        </StyledForm>
      </StyledPaper>
    </>
  );
}
