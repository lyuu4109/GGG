import React, { useState } from "react";
import {
  CssBaseline,
  Typography,
  Grid,
  Checkbox,
  Button,
  Avatar,
  LinearProgress,
} from "@mui/material";
import Link from "next/link";
import { createTheme } from "@mui/material/styles";
import { styled } from "@mui/system"; // Import styled from @mui/system
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const theme = createTheme({
  palette: {
    primary: {
      main: "#000", // Black color for primary
    },
    secondary: {
      main: "#000", // Black color for secondary
    },
    error: {
      main: "#f44336", // Red color for error
    },
    background: {
      default: "#fff", // White color for background
    },
  },
});

// Define styles using the styled function
const StyledPaper = styled("div")({
  margin: theme.spacing(1, 4),
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
});

const StyledForm = styled("form")({
  width: "100%", // Fix IE 11 issue.
  marginTop: theme.spacing(1),
  marginBottom: theme.spacing(3),
});

const StyledInputLabel = styled("label")({
  border: "2px solid #000",
  borderRadius: "4px",
  padding: "5px 10px",
  textAlign: "center",
  cursor: "pointer",
  display: "block",
  width: "fit-content",
  margin: "auto",
});

const StyledInput = styled("input")({
  display: "none",
});

const StyledTextField = styled("input")({
  border: "2px solid #000",
  borderRadius: "4px",
  padding: "10px",
  width: "100%",
  boxSizing: "border-box",
  marginTop: theme.spacing(1),
});

const StyledImage = styled("img")({
  width: "100px", // Adjust size as needed
  height: "100px", // Adjust size as needed
  borderRadius: "50%", // Ensure rounded shape
  objectFit: "cover", // Ensure image fills the container
});

const StyledDeleteButton = styled("div")({
  borderRadius: "50%",
  height: "30px",
  width: "30px",
  position: "absolute",
  left: "53%",
  top: "170px",
  cursor: "pointer",
  color: "#fff",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "20px",
  fontWeight: "bold",
  textAlign: "center",
  backgroundColor: "#f44336", // Red color for delete button
  "&:hover": {
    backgroundColor: "#d32f2f", // Darker red color on hover
  },
});

const StyledSubmitButton = styled(Button)({
  margin: theme.spacing(2, 0, 2),
  backgroundColor: "#000", // Black color for background
  "&:hover": {
    backgroundColor: "#000", // Black color for background on hover
  },
  "&:focus": {
    backgroundColor: "#000", // Black color for background on focus
  },
  "&:active": {
    backgroundColor: "#000", // Black color for background on active
  },
});

const StyledImageContainer = styled("div")({
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
});

export default function CreateAccount({ tabChange }) {
  const [formData, setFormData] = useState({
    name: "",
    profile: null,
    email: "",
    password: "",
    address: "",
    phone: "",
  });
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(false);
  const [image, setImage] = useState(null);
  const handleChange = async (e) => {
    const { name, type } = e.target;
    const newValue = type === "file" ? e.target.files[0] : e.target.value;
    type === "file" && setImage(URL.createObjectURL(newValue));
    setFormData((prevData) => ({
      ...prevData,
      [name]: newValue,
    }));
    if (type === "file") {
      setLoading(true);
      const formData = new FormData();
      formData.append("image", newValue);

      try {
        const response = await axios.post(
          process.env.NEXT_PUBLIC_SERVER_API + "api/upload/image",
          formData,
          {
            onUploadProgress: (progressEvent) => {
              const progress = Math.round(
                (progressEvent.loaded / progressEvent.total) * 100
              );
              setUploadProgress(progress);
            },
          }
        );
        setFormData((prevData) => ({
          ...prevData,
          profile: response.data.filename,
        }));
        setLoading(false);
        setUploadProgress(false);
        toast.success("Image uploaded successfully!");
      } catch (error) {
        console.error("Upload failed:", error);
        setLoading(false);
        toast.error("Failed to upload image. Please try again.");
      }
    }
  };

  const handleDeleteImage = () => {
    setFormData((prevData) => ({
      ...prevData,
      profile: null,
    }));
    setImage(false);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post(
        process.env.NEXT_PUBLIC_SERVER_API + "api/user/register",
        formData
      );
      console.log(response.data);
      setLoading(false);
      toast.success("Sign up successful!");
    } catch (error) {
      console.log(error);
      setLoading(false);
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        toast.error(error.response.data.message);
      } else if (
        error.response &&
        error.response.data &&
        error.response.data.errors
      ) {
        toast.error(error.response.data.errors[0].msg);
      } else {
        toast.error("An error occurred. Please try again later.");
      }
    }
  };

  return (
    <>
      <CssBaseline />
      <ToastContainer />
      <StyledPaper>
        <Typography component="h1" variant="h4">
          Sign up
        </Typography>
        <Typography component="p" variant="body1">
          Create an account for you or your company
        </Typography>
        <StyledForm onSubmit={handleSubmit}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              {image ? (
                <>
                  <StyledImageContainer>
                    <StyledImage src={image} alt="Profile Picture" />
                    {!uploadProgress && (
                      <StyledDeleteButton
                        onClick={handleDeleteImage}
                        variant="round"
                      >
                        ⨉
                      </StyledDeleteButton>
                    )}
                  </StyledImageContainer>
                </>
              ) : (
                <>
                  <Avatar
                    sx={{
                      m: "auto",
                      mb: 2,
                      bgcolor: "#000",
                      width: 80,
                      height: 80,
                    }}
                  ></Avatar>
                  <StyledInputLabel htmlFor="profile">
                    Upload Picture
                    <StyledInput
                      accept="image/*"
                      id="profile"
                      name="profile"
                      type="file"
                      onChange={handleChange}
                    />
                  </StyledInputLabel>
                </>
              )}
              {uploadProgress && (
                <>
                  <Typography variant="body1">
                    Uploading... {uploadProgress}%
                  </Typography>
                  <LinearProgress
                    variant="determinate"
                    value={uploadProgress}
                  />
                </>
              )}
            </Grid>
            {/* Other form fields */}
            <Grid item xs={12}>
              <StyledTextField
                type="text"
                autoComplete="name"
                name="name"
                placeholder="Name"
                value={formData.name}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <StyledTextField
                type="email"
                autoComplete="email"
                name="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <StyledTextField
                type="password"
                autoComplete="current-password"
                name="password"
                placeholder="Password"
                value={formData.password}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <StyledTextField
                type="text"
                name="address"
                placeholder="Address"
                value={formData.address}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <StyledTextField
                type="tel"
                name="phone"
                placeholder="Phone"
                value={formData.phone}
                onChange={handleChange}
              />
            </Grid>
          </Grid>

          <StyledSubmitButton
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            disabled={loading || uploadProgress}
          >
            {loading
              ? "Signing up..."
              : uploadProgress
              ? "Uploading..."
              : "Sign Up"}
          </StyledSubmitButton>
          <Grid container justify="center" style={{ justifyContent: "center" }}>
            <Grid item>
              <Link href="#" variant="body2">
                Already have an account?{" "}
                <span
                  onClick={() => {
                    tabChange("login");
                  }}
                >
                  Sign in
                </span>
              </Link>
            </Grid>
          </Grid>
        </StyledForm>
      </StyledPaper>
    </>
  );
}
