import React from 'react'
import style from "./ProductCard.module.css"
export default function ProductCard() {
  return (
    <div>ProductCard</div>
  )
}
