import React from "react";
import Image from "next/image";
import notFoundSvg from "../../../../public/images/not-found.svg";
import style from "./ProductNotFound.module.css";
export default function ProductNotFound() {
  return (
    <div className={style.notFound}>
      <Image src={notFoundSvg} alt="not found" width={200} height={200} />
      <p>No Products Found</p>
    </div>
  );
}
