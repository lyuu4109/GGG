"use client";
import Checkout from "@/components/productDetails/checkout/Checkout";
export default function page({ params }) {
  return (
    <>
      <Checkout productId={params.productId} userID={params.userId} />
    </>
  );
}
