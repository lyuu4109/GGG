import Edit from "@/components/profile/Edit";
import React from "react";

export default function page() {
  return (
    <div>
      <Edit />
    </div>
  );
}
