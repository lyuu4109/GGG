import Navbar from "@/components/Navigations/Navbar";
import NestedMenu from "@/components/Navigations/NestedMenu";
import { serverApi } from "@/lib/utils";
import Image from "next/image";
import style from "../style.module.css";

export default async function page({ params }) {
  const { id } = params;

  const res = await fetch(`${serverApi}/blog/${id}`);
  const singleBlog = await res.json();

  return (
    <div>
      <Navbar />
      <div style={{ margin: "4rem 0px" }}>
        <NestedMenu />

        <div>
          <Image
          className={style.blogImg}
            src={singleBlog?.blog?.blogimg}
            alt={singleBlog?.blog?.title}
            width={1000}
            height={400}
          />

          <div className={style.blogContent}>
            <h1 className={style.title}>{singleBlog?.blog?.title}</h1>
            <p>{singleBlog?.blog?.desc}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
