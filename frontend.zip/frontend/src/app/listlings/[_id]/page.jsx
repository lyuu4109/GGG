import ProductDetail from "@/components/productDetails/ProductDetail";

export default function page({ params: { _id } }) {
  return (
    <div>
      <ProductDetail productId={_id} />
    </div>
  );
}
