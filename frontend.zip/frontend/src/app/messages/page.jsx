'use client'
import Navbar from "@/components/Navigations/Navbar";
import NestedMenu from "@/components/Navigations/NestedMenu";
import React from "react";
import Footer from "@/components/Navigations/Footer";
import MessagesSection from "@/components/messages/messagesSection";
import style from './style.module.css'


export default function Message() {
    return (
        <div className={style.page}>
            <Navbar />
            <div
                style={{
                    display: "flex",
                    flexDirection: "column",
                    height: "100%",
                    marginBottom: "50px",
                }}
            >
                <NestedMenu />
            </div>
            <div className={style.container}>
                <MessagesSection />
            </div>
            <Footer />
        </div>
    );
}
