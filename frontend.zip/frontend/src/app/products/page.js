
const page = () => {
  return (
    <h1>products</h1>
  );
};

export default page;
