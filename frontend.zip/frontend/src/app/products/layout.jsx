"use client";
import React from "react";
import Footer from "@/components/Navigations/Footer";
import Navbar from "@/components/Navigations/Navbar";
import NestedMenu from "@/components/Navigations/NestedMenu";
import { FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import Pagination from "@mui/material/Pagination";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import style from "./style.module.css";
import FilterBar from "@/components/FilterBar/FilterBar";
import ProductNotFound from "@/components/productDetails/ProductNotFound/ProductNotFound";
import Loading from "@/components/Loading/Loading";
import TimeAgo from 'react-timeago'

export default function ProductLayout({ children }) {
  const [filters, setFilters] = useState({});
  const [sidebarOpen, setSidebarOpen] = useState(false); // Step 1
  const [minPrice, setMinPrice] = useState(""); // State for minimum price
  const [maxPrice, setMaxPrice] = useState("");
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [totalPages, setTotalPages] = useState(1);
  const [sortOption, setSortOption] = useState("");
  const [keywords, setKeywords] = useState(""); // State for keywords filter
  const searchParams = useSearchParams();
  const search = searchParams.get("search");
  const [loading, setLoading] = useState(true);

  const handleSortChange = (event) => {
    const option = event.target.value;
    setSortOption(option);
    if (option === "lowPrice") {
      setProducts([...products.sort((a, b) => a.price - b.price)]);
    } else if (option === "highPrice") {
      setProducts([...products.sort((a, b) => b.price - a.price)]);
    } else if (option === "new") {
      setProducts([
        ...products.sort(
          (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
        ),
      ]);
    } else {
      // Default sorting or any other sorting logic
    }
  };
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen); // Step 2
  };
  const handlePagination = async (event, pageNum) => {
    setPage(pageNum);
  };

  useEffect(() => {
    const fetchProducts = async (pageNum) => {
      setLoading(true);
      try {
        const response = await fetch(
          `${
            process.env.NEXT_PUBLIC_SERVER_API
          }api/products?page=${pageNum}&limit=8&search=${search ? search : ""}`,
          { cache: "no-store" }
        );
        if (!response.ok) {
          throw new Error("Failed to fetch products");
        }
        const data = await response.json();
        const newProducts = data.products;
        if (newProducts.length > 0) {
          setProducts(newProducts);
          setPage(data.currentPage);
          setTotalPages(data.totalPages);
          setHasMore(true);
        } else {
          setHasMore(false);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        // Handle error state here
      }
      setLoading(false);
    };

    fetchProducts(page);
  }, [page, search]);

  // Function to handle checkbox change and update filters
  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    console.log(name, checked);
    setFilters({ ...filters, [name]: checked });
  };

  // Function to filter products based on selected filters
  const filterProducts = (product) => {
    // Check if product matches all selected filters
    for (const filter in filters) {
      if (filters[filter] && filter !== "minPrice" && filter !== "maxPrice") {
        if (filter === "size") {
          if (!product.size.includes(filters[filter])) {
            return false;
          }
        } else if (filter === "minPrice") {
          if (parseInt(product.price) < parseInt(filters[filter])) {
            return false;
          }
        } else if (filter === "maxPrice") {
          if (parseInt(product.price) > parseInt(filters[filter])) {
            return false;
          }
        } else if (
          product.department !== filter &&
          product.category !== filter &&
          product.subcategory !== filter &&
          product.designers !== filter &&
          product.conditon !== filter
        ) {
          return false;
        }
      }
    }
    // Check min and max price filter
    if (minPrice && parseInt(product.floorPrice) < parseInt(minPrice)) {
      return false;
    }
    if (maxPrice && parseInt(product.floorPrice) > parseInt(maxPrice)) {
      return false;
    }
    if (
      keywords &&
      !product.productName.toLowerCase().includes(keywords.toLowerCase())
    ) {
      return false;
    }

    return true;
  };

  // Function to handle min price input change

  const calculateDiscountPercentage = (price, floorPrice) => {
    return ((price - floorPrice) / price) * 100;
  };

  // Function to handle min price input change
  const handleMinPriceChange = (event) => {
    const { value } = event.target;
    setMinPrice(value);
  };

  // Function to handle max price input change
  const handleMaxPriceChange = (event) => {
    const { value } = event.target;
    setMaxPrice(value);
  };
  const handleKeywordsChange = (event) => {
    const { value } = event.target;
    setKeywords(value);
  };

  return (
    <div>
      <Navbar />
      <div
        style={{
          marginTop: "4rem ",
          border: "1px solid black",
          width: "100vw",
        }}
      >
        <NestedMenu />
      </div>
      <div className={style.container}>
        <div className={style.topFilter}>
          <span style={{ fontWeight: "bold" }}>100+ listings</span>
          <div style={{ display: "flex", alignItems: "center" }}>
            <button
              style={{
                background: "black",
                color: "white",
                border: "none",
                padding: "10px 25px",
                fontWeight: "bold",
              }}
            >
              Follow
            </button>
            <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
              <InputLabel id="demo-select-small-label">Sort By</InputLabel>
              <Select
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={sortOption}
                onChange={handleSortChange}
                label="Sort by"
              >
                <MenuItem value="lowPrice">Low Price</MenuItem>
                <MenuItem value="highPrice">High Price</MenuItem>
                <MenuItem value="new">New</MenuItem>
              </Select>
            </FormControl>
          </div>
        </div>
        <div className={style.wrapper}>
          <FilterBar
            style={style}
            sidebarOpen={sidebarOpen}
            handleCheckboxChange={handleCheckboxChange}
            minPrice={minPrice}
            maxPrice={maxPrice}
            handleMinPriceChange={handleMinPriceChange}
            handleMaxPriceChange={handleMaxPriceChange}
            keywords={keywords}
            handleKeywordsChange={handleKeywordsChange}
          />
          <div className={style.ProCol}>
            <div className={style.productWrapprer}>
              {/* {children} */}
              {loading ? (
                <Loading text="Product are loading..." />
              ) : products.length > 0 ? (
                products.filter(filterProducts).map((x) => {
                  return (
                    <div key={x._id} className={style.ProductSlides}>
                      <Link
                        style={{
                          textDecoration: "none",
                          cursor: "pointer",
                          color: "black",
                        }}
                        href={`/listings/${x._id}`}
                        passHref
                      >
                        <div className={style.imgCol}>
                          <img src={process.env.NEXT_PUBLIC_SERVER_API + "uploads/" +x.productImages[0]} alt="" />
                          {!x.vendor ? (
                            ""
                          ) : (
                            <span className={style.tags}>{x.vendor}</span>
                          )}
                        </div>
                        <p>
                          <TimeAgo date={x.createdAt} />
                        </p>

                        <hr />
                        <div className={style.descCol}>
                          <p className={style.title}>
                            {x.productName.slice(0, 15)}...
                          </p>
                          <p>{x.description.slice(0, 25)}</p>
                        </div>
                      </Link>
                      <div className={style.priceCol}>
                        <p className={style.price}>
                          <span style={{ color: "red", margin: "0px 2px" }}>
                            {" "}
                            ${x.floorPrice ? x.floorPrice : ""}
                          </span>
                          <span className={style.floorPrice}>${x.price}</span>
                          <span className={style.discount}>
                            {" "}
                            {`${calculateDiscountPercentage(
                              x.price,
                              x.floorPrice
                            ).toFixed(0)}% off`}
                          </span>
                        </p>
                        <button className={style.btn}>
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth="1.5"
                            stroke="currentColor"
                            width={24}
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z"
                            />
                          </svg>
                        </button>
                      </div>
                    </div>
                  );
                })
              ) : (
                <ProductNotFound />
              )}
            </div>
          </div>
        </div>
        <Pagination
          style={{
            margin: "20px",
            display: "flex",
            justifyContent: "end",
            width: "100%",
          }}
          count={totalPages}
          shape="rounded"
          page={page}
          onChange={handlePagination}
        ></Pagination>
      </div>
      <Footer />
    </div>
  );
}
