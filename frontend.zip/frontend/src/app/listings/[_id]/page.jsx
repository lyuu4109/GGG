import Sold from "@/components/productDetails/Sold";

export default function page({ params: { _id } }) {
  return (
    <div>
      <Sold productId={_id} />
    </div>
  );
}
