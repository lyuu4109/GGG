import Modals from '@/components/authModal/Modals'
import React from 'react'

export default function page() {
  return (
    <div>
      <Modals/>
    </div>
  )
}
