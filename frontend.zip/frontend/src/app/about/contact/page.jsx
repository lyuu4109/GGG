import ContactForm from '@/components/contactForm/ContactForm'
import React from 'react'

export default function page() {
  return (
    <div>
      <ContactForm/>
    </div>
  )
}
