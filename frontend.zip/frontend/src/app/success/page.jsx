import React from 'react'

export default function page() {
  return (
    <div>
      payment sucess
    </div>
  )
}
