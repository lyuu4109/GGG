export { default } from "next-auth/middleware";
// next.config.js

  
export const config = { matcher: ["/"] };
