// middleware/authMiddleware.js

const jwt = require("jsonwebtoken");
const User = require("../models/User");

const authMiddleware = async (req, res, next) => {
  try {
    // Get token from request headers
    const token = req.headers.authorization.split(" ")[1];

    if (!token) {
      return res
        .status(401)
        .json({ status: "error", message: "Unauthorized: Missing token" });
    } // Verify token

    const decoded = jwt.verify(token, process.env.JWT_SECRET); // Fetch user from database using user ID from decoded token

    if (decoded) {
      const user = await User.findById(decoded.userId);

      if (!user) {
        return res
          .status(401)
          .json({ status: "error", message: "Unauthorized: User not found" });
      } // Attach user object to request for further processing

      req.user = user; // Proceed to the next middleware
      next();
    } else {
      throw new Error("Invalid token");
    }
  } catch (error) {
    return res
      .status(401)
      .json({ status: "error", message: "Unauthorized: Invalid token" });
  }
};

module.exports = authMiddleware;
