// Importing Mongoose library
const mongoose = require("mongoose");

// Defining the product schema
const productSchema = new mongoose.Schema(
  {
    // User ID of the vendor who owns the product, referencing Vendor model
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    // Name of the user who owns the product, required field
    userName: { type: String, required: true },
    // Shipping information for the product, defaulting to null
    shippings: { type: String, default: null },
    // Images of the product
    productImages: [{ type: String }],
    // Designers associated with the product
    designers: { type: String },
    // Name of the product, required field
    productName: { type: String, required: true },
    // Size of the product
    size: { type: String },
    // Color of the product
    color: { type: String },
    // Price of the product, required field
    price: { type: Number, required: true },
    // Floor price of the product
    floorPrice: { type: Number },
    // Description of the product
    description: { type: String },
    // Vendor name
    vendor: { type: String },
    // Condition of the product
    condition: { type: String },
    // Department of the product
    department: { type: String },
    // Category of the product
    category: { type: String },
    // Subcategory of the product
    subcategory: { type: String },
    // Tags associated with the product
    tags: [{ type: String }],
    // Flag indicating whether offers are accepted for the product, defaulting to true
    acceptOffer: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Creating Product model based on the product schema
const Product = mongoose.model("Product", productSchema);

// Exporting the Product model
module.exports = Product;
