// Importing Mongoose library
const mongoose = require("mongoose");

// Defining the user schema
const userSchema = new mongoose.Schema(
  {
    // Name of the user, required field
    name: { type: String, required: true },
    // Profile of the user, required field
    profile: { type: String },
    // Email of the user, required and unique field
    email: { type: String, required: true, unique: true },
    // Password of the user, required field
    password: { type: String, required: true },
    // Address of the user, required field
    address: { type: String, required: true },
    // Phone number of the user, required field
    phone: { type: String, required: true },
  },
  // Including timestamps for creation and update
  { timestamps: true }
);

// Creating User model based on the user schema
const User = mongoose.model("User", userSchema);

// Exporting the User model
module.exports = User;
