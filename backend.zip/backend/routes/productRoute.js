const router = require("express").Router();

// Include controllers
const productController = require("../controllers/productController");

// Include routes
router.get("/", productController.getProducts);

router.get("/:id", productController.getProduct);

router.post("/", productController.createProduct);

router.patch("/:id", productController.updateProduct);

router.delete("/:id", productController.deleteProduct);

module.exports = router;
