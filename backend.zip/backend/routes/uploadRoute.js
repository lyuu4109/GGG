const express = require("express");
const multer = require("multer");
const path = require("path"); // Import the path module
const { uploadImage, uploadFile } = require("../controllers/uploadController");

const router = express.Router();
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({ storage: storage });

// Route for uploading image
router.post("/image", upload.single("image"), uploadImage);

// Route for uploading file
router.post("/file", upload.single("file"), uploadFile);

module.exports = router;
