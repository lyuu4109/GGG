// routes/userRoutes.js

const express = require("express");
const router = express.Router();
const {
  validateRegistration,
  validateLogin,
} = require("../validators/userValidation");
const {
  registerUser,
  loginUser,
  verifyUser,
  viewProfile,
} = require("../controllers/userController");
const authMiddleware = require("../middleware/authCheck");

// Route for user registration
router.post("/register", validateRegistration, registerUser);

// Route for user login
router.post("/login", validateLogin, loginUser);

// Route for user verification
router.post("/verify", authMiddleware, verifyUser);

// Route for user profile
router.get("/profile/:id", viewProfile);

module.exports = router;
