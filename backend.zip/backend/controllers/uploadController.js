// Function to handle image upload
const uploadImage = (req, res) => {
  try {
    const filename = req.file.filename;
    res.json({ filename: filename });
  } catch (error) {
    console.error("Error uploading image:", error);
    res.status(500).json({ message: "Failed to upload image" });
  }
};

// Function to handle file upload
const uploadFile = (req, res) => {
  try {
    const filename = req.file.filename;
    res.json({ filename: filename });
  } catch (error) {
    console.error("Error uploading file:", error);
    res.status(500).json({ message: "Failed to upload file" });
  }
};

module.exports = { uploadImage, uploadFile };
