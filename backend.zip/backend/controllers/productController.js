const Product = require("../models/product");

const productController = {
  // Get all products with pagination
  async getProducts(req, res) {
    try {
      const { page = 1, limit = 10, search = "" } = req.query;
      const skip = (parseInt(page, 10) - 1) * parseInt(limit, 10);
      const query = search ? { $text: { $search: search } } : {};

      const totalProducts = await Product.countDocuments(query);
      const totalPages = Math.ceil(totalProducts / parseInt(limit, 10));

      const products = await Product.find(query)
        .skip(skip)
        .limit(parseInt(limit, 10));

      res.json({
        products,
        totalPages,
        currentPage: parseInt(page, 10),
        totalProducts,
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },

  // Get a single product by ID
  async getProduct(req, res) {
    try {
      const product = await Product.findById(req.params.id);
      if (product) {
        res.json(product);
      } else {
        res.status(404).json({ message: "Product not found" });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },

  // Create a new product
  async createProduct(req, res) {
    const product = new Product(req.body);
    try {
      const newProduct = await product.save();
      res.status(201).json(newProduct);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  },

  // Update a product by ID
  async updateProduct(req, res) {
    try {
      const product = await Product.findById(req.params.id);
      if (product) {
        // Update product fields
        product.set(req.body);
        const updatedProduct = await product.save();
        res.json(updatedProduct);
      } else {
        res.status(404).json({ message: "Product not found" });
      }
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  },

  // Delete a product by ID
  async deleteProduct(req, res) {
    try {
      const product = await Product.findById(req.params.id);
      if (product) {
        // Remove product from database
        await Product.deleteOne({ _id: req.params.id });
        res.json({ message: "Product deleted" });
      } else {
        res.status(404).json({ message: "Product not found" });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  },
};

module.exports = productController;
